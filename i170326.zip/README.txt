Dependencies:
-Python 3 (tested on 3.7)
-Pycryptodome

To run:
-Run server.py in one terminal
-Run client.py in another terminal